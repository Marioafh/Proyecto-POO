package automovilescaribe;
import Interfaces.InterfazAdmi;
import java.awt.List;
import java.io.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;


public class AutomovilesCaribe {

    //Vinuclo de ubicación de Archivos
//    private static final String PATH = "/Users/andreacarolinaperezconde/Documents/automovilesCaribe/src/Files/";
            
            
    public static void main(String[] args) {
        InterfazAdmi Ventana = new InterfazAdmi();
        Ventana.setVisible(true); //Mostrar Ventana
        Ventana.setLocationRelativeTo(null); //Para centrar la ventana
//    
////        String name = null;
////        File archivo = new File(PATH + name);
//        
//        File Empleados = new File ("/Users/andreacarolinaperezconde/Documents/automovilesCaribe/src/Files/Empleados.txt");
////        File Carros = new File("carros.txt");
////        
////        //ArrayList con la cedula y nombre del empleado 
////        
//        ArrayList<String> Empleado = new ArrayList<String>();
////        
//        try(BufferedReader LectorEmpleado = new BufferedReader(new FileReader(Empleados)) ){
//            
//            //Se crea una variable para guardar la info necesaria
//            String Employee;
//            
//            //se lee el archivo y se extrae la cedula y nombre
//            while((Employee = LectorEmpleado.readLine()) != null){
//            String[] EmployeeArray = Employee.split(",", 6);
//            Employee = EmployeeArray[0].trim() + "," + EmployeeArray[1].trim() + ",";
//            Empleado.add(Employee);
//            for(int i = 0 ; i < Empleado.size(); i++){
//                System.out.println(Empleado.get(i) + "iNTERACION NUMERO: " + i);
//                
//            }
//            
//            }
//            
//            LectorEmpleado.close();
//            
//        }catch (IOException ex) {
//            System.out.println("Fallo " + ex.getMessage());
//        }
//        
//        
//        ArrayList<String> Car = new ArrayList<String>();
//        
//        try(BufferedReader LectorCarros = new BufferedReader(new FileReader(Carros)) ){
//            
//            //Se crea una variable para guardar la info necesaria
//            String car;
//            
//            //se lee el archivo y se extrae el código, marca y precio
//            while((car = LectorCarros.readLine()) != null){
//            String[] CarArray = car.split(",");
//            car = CarArray[0].trim() + "," + CarArray[1].trim() + "," + CarArray[2].trim();
//            Car.add(car);
//            
//            }
//            
//            LectorCarros.close();
//    }catch (IOException ex) {
//            System.out.println("Fallo " + ex.getMessage());
//        }
    }
    
    
    public void LlenarTabla(String PATH, DefaultTableModel registro){
                try {
            File archivo = new File(PATH);
            FileReader fr = new FileReader(archivo);
            BufferedReader bw = new BufferedReader(fr);
            String linea;
            while ((linea = bw.readLine()) != null) {
                String[] fila = linea.split(",");
                registro.addRow(fila);
            }
            bw.close();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(InterfazAdmi.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(InterfazAdmi.class.getName()).log(Level.SEVERE, null, ex);
            } 
    }
    
    public void ActualizarArrayListEmpleados(ArrayList<String> ArrayList, String PATH){
        ArrayList.clear();
        try (BufferedReader readerArchivoEmpleados = new BufferedReader(new FileReader(PATH))) {

            String lineaEmpleado = null;

            while ((lineaEmpleado = readerArchivoEmpleados.readLine()) != null) {
                String[] lineaEmpleadoArray = lineaEmpleado.split(",", 7);
                lineaEmpleado = lineaEmpleadoArray[0].trim() + ", " + lineaEmpleadoArray[1].trim() + ",";
                ArrayList.add(lineaEmpleado);
            }
            readerArchivoEmpleados.close();
        } catch (IOException ex) {
            System.out.println("Fallo " + ex.getMessage());
        }
    }
    
    public void ArrayListEmpleadosCompletos(ArrayList<String> ArrayList, String PATH) {
        ArrayList.clear();
        try (BufferedReader readerArchivoEmpleados = new BufferedReader(new FileReader(PATH))) {

            String lineaEmpleado = null;

            while ((lineaEmpleado = readerArchivoEmpleados.readLine()) != null) {
                String[] lineaEmpleadoArray = lineaEmpleado.split(",", 8);
                lineaEmpleado = lineaEmpleadoArray[0].trim() + ", " + lineaEmpleadoArray[1].trim() + ", " + lineaEmpleadoArray[2].trim() + ", " + lineaEmpleadoArray[3].trim() + ", " + lineaEmpleadoArray[4].trim() + ", " + lineaEmpleadoArray[5].trim() + ", " + lineaEmpleadoArray[6].trim() + ", " + lineaEmpleadoArray[7].trim();
                ArrayList.add(lineaEmpleado);
            }
            readerArchivoEmpleados.close();
        } catch (IOException ex) {
            System.out.println("Fallo " + ex.getMessage());
        }
    }
    
    public void ActualizarArrayListCarros(ArrayList<String> ArrayList, String PATH){
        ArrayList.clear();
        
        try (BufferedReader readerArchivoEmpleados = new BufferedReader(new FileReader(PATH))) {

            String lineaEmpleado = null;

            while ((lineaEmpleado = readerArchivoEmpleados.readLine()) != null) {
                String[] lineaEmpleadoArray = lineaEmpleado.split(",", 4);
                lineaEmpleado = lineaEmpleadoArray[0].trim() + ", " + lineaEmpleadoArray[3].trim() + "," + lineaEmpleadoArray[1].trim() + "," + lineaEmpleadoArray[2].trim();
                ArrayList.add(lineaEmpleado);
            }
            readerArchivoEmpleados.close();
        } catch (IOException ex) {
            System.out.println("Fallo " + ex.getMessage());
        }
    }
    
    public void ActualizarArrayListVentas(ArrayList<String> ArrayList, String PATH){
        ArrayList.clear();
    try (BufferedReader readerArchivoEmpleados = new BufferedReader(new FileReader(PATH))) {

        String lineaEmpleado = null;

        while ((lineaEmpleado = readerArchivoEmpleados.readLine()) != null) {
            String[] lineaEmpleadoArray = lineaEmpleado.split(",", 5);
            lineaEmpleado = lineaEmpleadoArray[0].trim() + ", " + lineaEmpleadoArray[1].trim() + "," + ", " + lineaEmpleadoArray[2].trim() + ", " + lineaEmpleadoArray[3].trim() + ", " + lineaEmpleadoArray[4].trim();
            ArrayList.add(lineaEmpleado);
        }
        readerArchivoEmpleados.close();
    } catch (IOException ex) {
        System.out.println("Fallo " + ex.getMessage());
    }
    }
    
    public void AgregarRegistro(String PATH, String text) {
        File archivo = new File(PATH);
        try {
            try (BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo, true))) {
                escritor.write(text + "\n");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void Escribir(String PATH, String text) {
        File archivo = new File(PATH);
        try {
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo));
            escritor.write(text);
            escritor.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void CrearArchivo(String PATH, String name) {
        File file = new File(PATH + name);
        try {
            file.createNewFile();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void borrar(File archivo) {
        if (!archivo.exists()) { // Si el fichero no existe no hacemos nada.
            System.out.println("El archivo data no existe.");
        } else { // Si el fichero existe, se lo pasamos al constructor de FileWriter
            FileWriter fw;
            try {
                fw = new FileWriter(archivo);
                fw.flush(); // Vaciamos el fichero        
                fw.close(); // Cerramos el "canal de comunicación" con el fichero
                System.out.println("El archivo data fue eliminado.");
            } catch (IOException ex) {
                System.out.println("Error al borrar contenido del fichero");
            }
        }
    }
    
}
