package automovilescaribe;

import java.io.*;

public class ManejoArchivos {
    
    private static final String PATH = "/Users/andreacarolinaperezconde/Documents/Aerolinea_AirExpress/src/Files/";

    public static void create(String name) {
        File file = new File(PATH + name);
        try {
            file.createNewFile();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void append(String name, String text) {
        File archivo = new File(PATH + name);
        try {
            try (BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo, true))) {
                escritor.write(text + "\n");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void write(String name, String text) {
        File archivo = new File(PATH + name);
        try {
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo));
            escritor.write(text);
            escritor.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static String read(String name) {
        File archivo = new File(PATH + name);
        try {
            BufferedReader lector = new BufferedReader(new FileReader(archivo));

            String text = "";
            String line;
            while ((line = lector.readLine()) != null) {
                text += line + "\n";
            }

            lector.close();

            return text;
        } catch (IOException e) {
            System.out.println("Fallo");
        }
        return null;
    }

    public static void delete(String name) {
        File archivo = new File(PATH + name);
        archivo.delete();
    }

    public static void deleteLine(String name, String eliminar) {
        String contenido = read(name);
        String[] lineas = contenido.split("\n");
        String nuevoText = "";

        for (int i = 0; i < lineas.length; i++) {
            if (!lineas[i].equals(eliminar)) {
                nuevoText += lineas[i] + "\n";
            }
        }

    }
}
